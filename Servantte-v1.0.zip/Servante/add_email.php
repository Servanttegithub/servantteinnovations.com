<?php
$servername = "localhost";
$username = "root";
$password = ""; // Your database password
$dbname = "message";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get email from POST request
$email = $_POST['email'];

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format";
    exit;
}

// Get current date and time
$date = date('Y-m-d');
$time = date('H:i:s');

// Insert data into email_list table
$sql = "INSERT INTO email_list (email, subscription_date, subscription_time)
VALUES ('$email', '$date', '$time')";

if ($conn->query($sql) === TRUE) {
    echo "Email subscribed successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
